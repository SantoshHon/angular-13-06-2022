import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TravelDetails } from 'src/app/pojo/TravelDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TraveldetailsServiceService } from 'src/app/service/traveldetails.service';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';


@Component({
  selector: 'app-view-booking-status',
  templateUrl: './view-booking-status.component.html',
  styleUrls: ['./view-booking-status.component.css']
})
export class ViewBookingStatusComponent implements OnInit {
  travelRequestId: number = 0;
  travellingRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();

  constructor(private traveldetailsServiceService: TraveldetailsServiceService, private route: ActivatedRoute, private travelingRequestDetailsService: TravelingRequestDetailsService) { }
  travelDetails: TravelDetails = new TravelDetails();
  ngOnInit(): void {
    this.travelRequestId = this.route.snapshot.params['travelRequestId'];
    this.reloadBookingDetails();

  }
  reloadBookingDetails() {
    this.travelingRequestDetailsService.getTravellingRequestDetailsBytravelRequestId(this.travelRequestId).subscribe(
      data => {
        this.travellingRequestDetails = data;
        this.travelDetails = this.travellingRequestDetails.travelDetails;
        console.log(this.travelDetails);
      }
    );
  }

}
