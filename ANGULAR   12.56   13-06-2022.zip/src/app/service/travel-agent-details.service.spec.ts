import { TestBed } from '@angular/core/testing';

import { TravalAgentDetailsService } from './travel-agent-details.service';

describe('TravelAgentDetailsService', () => {
  let service: TravalAgentDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravalAgentDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
