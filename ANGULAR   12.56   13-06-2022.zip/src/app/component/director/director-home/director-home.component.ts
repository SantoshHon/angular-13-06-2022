import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-director-home',
  templateUrl: './director-home.component.html',
  styleUrls: ['./director-home.component.css']
})
export class DirectorHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
