import { EmployeeDetails } from "./EmployeeDetails";
import { TravelDetails } from "./TravelDetails";
import { TravelDocumentDetails } from "./TravelDocumentDetails";

export class TravellingRequestDetails {
   travelRequestId: number = 0;
   travelDepartureDate: Date = new Date();
   travelReturndate: Date = new Date();
   travelReason: string = '';
   travelMode: string = '';
   tarvelStatus: string = 'PENDING';
   projectManagerStatus: string = 'PENDING';
   directorstatus: string = 'PENDING';
   travelLocation: string = '';
   employeeDetails: EmployeeDetails = new EmployeeDetails();
   travelDetails: TravelDetails = new TravelDetails();
   travelDocumentDetails: TravelDocumentDetails = new TravelDocumentDetails();
}