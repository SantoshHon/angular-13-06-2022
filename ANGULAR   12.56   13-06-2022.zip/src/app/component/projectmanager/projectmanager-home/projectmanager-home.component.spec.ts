import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectmanagerHomeComponent } from './projectmanager-home.component';

describe('ProjectmanagerHomeComponent', () => {
  let component: ProjectmanagerHomeComponent;
  let fixture: ComponentFixture<ProjectmanagerHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectmanagerHomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectmanagerHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
