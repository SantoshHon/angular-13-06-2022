import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPendingEmployeeRequestsComponent } from './view-pending-employee-requests.component';

describe('ViewPendingEmployeeRequestsComponent', () => {
  let component: ViewPendingEmployeeRequestsComponent;
  let fixture: ComponentFixture<ViewPendingEmployeeRequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPendingEmployeeRequestsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewPendingEmployeeRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
