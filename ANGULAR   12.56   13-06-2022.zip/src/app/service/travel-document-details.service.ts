import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TravelDocumentDetails } from '../pojo/TravelDocumentDetails';

@Injectable({
  providedIn: 'root'
})
export class TravelDocumentDetailsService {
  private baseURL: string = "http://localhost:8080/documentdetails/documentdetail";
  constructor(private http: HttpClient) { }

  getAllTravelDocumentDetails(): Observable<TravelDocumentDetails[]> {
    return this.http.get<TravelDocumentDetails[]>(this.baseURL);
  }

  getTravelDocumentDetailsByTravelDetailsId(documentId: number): Observable<TravelDocumentDetails> {
    console.log('in get single employee'+documentId);
    return this.http.get<TravelDocumentDetails>(this.baseURL + '/' + documentId);
  }
}
