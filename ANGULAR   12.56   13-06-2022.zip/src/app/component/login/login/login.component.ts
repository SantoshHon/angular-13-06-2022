import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { LoginDetails } from 'src/app/pojo/logindetails';
import { EmployeeDetailsService } from 'src/app/service/employee-details.service';
import { LoginDetailsService } from 'src/app/service/login-details.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginDetailsService: LoginDetailsService, private router: Router, private employeeDetailsService: EmployeeDetailsService) { }
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  loginDetails: LoginDetails = new LoginDetails();

  submitted: boolean = false;

  loadEmployeeDetails() {
    this.employeeDetailsService.getEmployeeByLoginId(this.loginDetails.loginId).subscribe(
      data => {
        this.employeeDetails = data;
        console.log(this.employeeDetails);
        sessionStorage.setItem('employee', JSON.stringify(this.employeeDetails));
      });

  }
  onLogin() {
    this.loginDetailsService.userLogin(this.loginDetails).subscribe(
      data => {
        this.loginDetails = data;
        if (this.loginDetails.role === 'DIRECTOR') {
          this.loadEmployeeDetails();
          this.router.navigate(['/directorhome']);
        }
        if (this.loginDetails.role === 'DEVELOPER') {
          this.loadEmployeeDetails();
          this.router.navigate(['/employeehome']);
        }
        if (this.loginDetails.role === 'MANAGER') {
          this.loadEmployeeDetails();
          this.router.navigate(['/projectmanagerhome']);
        }
        if (this.loginDetails.role === 'AGENT') {
          this.router.navigate(['/travelagenthome']);
        }
      }
    );
  }


  ngOnInit(): void {
  }

}
