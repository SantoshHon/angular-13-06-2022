import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { TravellingRequestDetails } from '../pojo/TravellingRequestDetails';

@Injectable({
  providedIn: 'root'
})
export class TravelingRequestDetailsService {

  private baseURL: string = "http://localhost:8080/travlingrequests/travlingrequest";
  private URLForTravelingRequestDetails: string = "http://localhost:8080/travlingrequests";
  constructor(private http: HttpClient, route: ActivatedRoute) { }

  getAllTravellingRequestDetails(): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.baseURL);
  }

  getTravellingRequestDetailsBytravelRequestId(travelRequestId: number): Observable<TravellingRequestDetails> {
    console.log('in get single employee' + travelRequestId);
    return this.http.get<TravellingRequestDetails>(this.baseURL + '/' + travelRequestId);
  }

  upadateMakeTravelRequest(travelRequestDetails: TravellingRequestDetails): Observable<TravellingRequestDetails> {
    return this.http.post<TravellingRequestDetails>(this.baseURL, travelRequestDetails);
  }

  updateTravelRequestStatus(travellingRequestDetails: TravellingRequestDetails): Observable<boolean> {
    console.log(travellingRequestDetails);
    return this.http.put<boolean>(this.baseURL, travellingRequestDetails);
  }

  getAllTravellingRequestDetailsByEmployeeId(employeeDetailsId: Number): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/requestsbyemployeeid/' + employeeDetailsId);
  }
  getTravelRequestsByManagerId(managerId: number): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/requestsformanager/' + managerId);
  }
  getAllTravellingRequestDetailsForaAgent(): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/requestsforagent');
  }
  updateManagerStatusBytravelRequestId(travellingRequestDetails: TravellingRequestDetails): Observable<boolean> {
    console.log(this.URLForTravelingRequestDetails + '/updatemanager', travellingRequestDetails);
    return this.http.put<boolean>(this.URLForTravelingRequestDetails + '/updatemanager', travellingRequestDetails);
  }

  getAllTravellingRequestsByRequestStatusForManager(requestStatus: string) {
    console.log(requestStatus);
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/travlingrequeststatus/' + requestStatus);
  }

  getAllTravellingPendingRequestByManagerId(managerId: number): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/pendingtravlingrequeststatus/' + managerId);
  }
  getAllTravellingAcceptRequestByManagerId(managerId: number): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/accepttravlingrequeststatus/' + managerId);
  }
  getAllTravellingRejectedRequestByManagerId(managerId: number): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/rejecttravlingrequeststatus/' + managerId);
  }
  getAllTravellingRequestDetailsForDirector(): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/requestsfordirector');
  }

  getAllAcceptedTravellingRequestDetailsForAgent(): Observable<TravellingRequestDetails[]> {
    return this.http.get<TravellingRequestDetails[]>(this.URLForTravelingRequestDetails + '/acceptedrequestsforagent');
  }

  insertTravalDetails(travellingRequestDetails: TravellingRequestDetails): Observable<boolean> {
    console.log(travellingRequestDetails);
    console.log(this.URLForTravelingRequestDetails+'/inserttravaldetail');
    
    return this.http.put<boolean>(this.URLForTravelingRequestDetails+'/inserttravaldetail', travellingRequestDetails);
  }
}