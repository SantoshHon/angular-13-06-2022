import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TravelDetails } from 'src/app/pojo/TravelDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-employee-travel-details',
  templateUrl: './employee-travel-details.component.html',
  styleUrls: ['./employee-travel-details.component.css']
})
export class EmployeeTravelDetailsComponent implements OnInit {

  travelRequestId: number = 0;
  travellingRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();
  travelDetails:TravelDetails=new TravelDetails();
  constructor(private route: ActivatedRoute, private travelingRequestDetailsService: TravelingRequestDetailsService) { }
  ngOnInit(): void {
    this.travelRequestId = this.route.snapshot.params['travelRequestId'];
    this.getTravelDetails();
  }

  getTravelDetails() {
    this.travelingRequestDetailsService.getTravellingRequestDetailsBytravelRequestId(this.travelRequestId).subscribe(
      data => {
        this.travellingRequestDetails = data;
        this.travelDetails=this.travellingRequestDetails.travelDetails
        console.log(this.travelDetails);
      }
    );
  }

}
