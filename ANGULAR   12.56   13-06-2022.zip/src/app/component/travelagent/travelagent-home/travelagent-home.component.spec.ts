import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelagentHomeComponent } from './travelagent-home.component';

describe('TravelagentHomeComponent', () => {
  let component: TravelagentHomeComponent;
  let fixture: ComponentFixture<TravelagentHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TravelagentHomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TravelagentHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
