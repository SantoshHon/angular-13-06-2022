import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentTravelRequestListComponent } from './agent-travel-request-list.component';

describe('AgentTravelRequestListComponent', () => {
  let component: AgentTravelRequestListComponent;
  let fixture: ComponentFixture<AgentTravelRequestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgentTravelRequestListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgentTravelRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
