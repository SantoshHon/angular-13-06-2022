import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-view-manager-travel-request',
  templateUrl: './view-manager-travel-request.component.html',
  styleUrls: ['./view-manager-travel-request.component.css']
})
export class ViewManagerTravelRequestComponent implements OnInit {

  allTravelRequests: TravellingRequestDetails[] = [];
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  employeeDetailsId: number = 0;
  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private router: Router) { }

  ngOnInit(): void {

    this.employeeDetails = JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.employeeDetailsId = this.employeeDetails.employeeDetailsId;
    console.log(this.employeeDetailsId);
    this.reloadData();

  }
  reloadData() {
    this.travelingRequestDetailsService.getAllTravellingRequestDetailsByEmployeeId(this.employeeDetailsId).subscribe(
      data => {
        this.allTravelRequests = data;
        console.log(this.allTravelRequests);
      }
    )
  }

  getdetails(travelRequestId: Number) {
    // this.router.navigate(['/employeehome/employeetraveldetails', travelRequestId]);
    this.router.navigate(['/projectmanagerhome/managerstraveldetails', travelRequestId]);
  }
}