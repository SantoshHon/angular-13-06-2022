import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login/login.component';
import { DirectorHomeComponent } from './component/director/director-home/director-home.component';
import { EmployeeHomeComponent } from './component/employee/employee-home/employee-home.component';
import { ProjectmanagerHomeComponent } from './component/projectmanager/projectmanager-home/projectmanager-home.component';
import { TravelagentHomeComponent } from './component/travelagent/travelagent-home/travelagent-home.component';
import { ViewEmployeeTravelRequestComponent } from './component/director/view-employee-travel-request/view-employee-travel-request.component';
import { MakeTravelRequestComponent } from './component/employee/make-travel-request/make-travel-request.component';
import { ViewTravelRequestComponent } from './component/employee/view-travel-request/view-travel-request.component';
import { ViewBookingStatusComponent } from './component/employee/view-booking-status/view-booking-status.component';
import { BookingDetailsComponent } from './component/travelagent/booking-details/booking-details.component';
import { AgentTravelRequestListComponent } from './component/travelagent/agent-travel-request-list/agent-travel-request-list.component';
import { ValidateRequestComponent } from './component/travelagent/validate-request/validate-request.component';
import { EmployeeTravelDetailsComponent } from './component/employee/employee-travel-details/employee-travel-details.component';
import { ShowEmployeeDetailsComponent } from './component/projectmanager/show-employee-details/show-employee-details.component';
import { ViewPendingEmployeeRequestsComponent } from './component/projectmanager/view-pending-employee-requests/view-pending-employee-requests.component';
import { MakeNewBookingsComponent } from './component/travelagent/make-new-bookings/make-new-bookings.component';
import { ViewManagerTravelRequestComponent } from './component/projectmanager/view-manager-travel-request/view-manager-travel-request.component';
import { ViewManagerBookingStatusComponent } from './component/projectmanager/view-manager-booking-status/view-manager-booking-status.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DirectorHomeComponent,
    EmployeeHomeComponent,
    ProjectmanagerHomeComponent,
    TravelagentHomeComponent,
    ViewEmployeeTravelRequestComponent,
    MakeTravelRequestComponent,
    ViewTravelRequestComponent,
    ViewBookingStatusComponent,
    BookingDetailsComponent,
    AgentTravelRequestListComponent,
    ValidateRequestComponent,
    EmployeeTravelDetailsComponent,
    ShowEmployeeDetailsComponent,
    ViewPendingEmployeeRequestsComponent,
    MakeNewBookingsComponent,
    ViewManagerTravelRequestComponent,
    ViewManagerBookingStatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
