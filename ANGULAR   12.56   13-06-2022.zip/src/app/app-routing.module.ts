import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DirectorHomeComponent } from './component/director/director-home/director-home.component';
import { ViewEmployeeTravelRequestComponent } from './component/director/view-employee-travel-request/view-employee-travel-request.component';
import { EmployeeHomeComponent } from './component/employee/employee-home/employee-home.component';
import { EmployeeTravelDetailsComponent } from './component/employee/employee-travel-details/employee-travel-details.component';
import { MakeTravelRequestComponent } from './component/employee/make-travel-request/make-travel-request.component';
import { ViewBookingStatusComponent } from './component/employee/view-booking-status/view-booking-status.component';
import { ViewTravelRequestComponent } from './component/employee/view-travel-request/view-travel-request.component';
import { LoginComponent } from './component/login/login/login.component';
import { ProjectmanagerHomeComponent } from './component/projectmanager/projectmanager-home/projectmanager-home.component';
import { ShowEmployeeDetailsComponent } from './component/projectmanager/show-employee-details/show-employee-details.component';
import { ViewManagerBookingStatusComponent } from './component/projectmanager/view-manager-booking-status/view-manager-booking-status.component';
import { ViewManagerTravelRequestComponent } from './component/projectmanager/view-manager-travel-request/view-manager-travel-request.component';
import { ViewPendingEmployeeRequestsComponent } from './component/projectmanager/view-pending-employee-requests/view-pending-employee-requests.component';
import { AgentTravelRequestListComponent } from './component/travelagent/agent-travel-request-list/agent-travel-request-list.component';
import { BookingDetailsComponent } from './component/travelagent/booking-details/booking-details.component';
import { MakeNewBookingsComponent } from './component/travelagent/make-new-bookings/make-new-bookings.component';
import { TravelagentHomeComponent } from './component/travelagent/travelagent-home/travelagent-home.component';
import { ValidateRequestComponent } from './component/travelagent/validate-request/validate-request.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'employeehome', component: EmployeeHomeComponent,
    children: [
      { path: 'maketravelrequest', component: MakeTravelRequestComponent },
      { path: 'viewbookingstatus/:travelRequestId', component: ViewBookingStatusComponent },
      { path: 'viewtravelrequest', component: ViewTravelRequestComponent },
      { path: 'employeetraveldetails/:travelRequestId', component: EmployeeTravelDetailsComponent }
    ]
  },
  {
    path: 'projectmanagerhome', component: ProjectmanagerHomeComponent,
    children: [
      { path: 'showemployeedetails/:travelRequestId', component: ShowEmployeeDetailsComponent },
      { path: 'viewemployeerequests', component: ViewPendingEmployeeRequestsComponent },
      { path: 'maketravelrequest', component: MakeTravelRequestComponent },
      // { path: 'viewtravelrequest', component: ViewTravelRequestComponent }
      // { path: 'viewbookingstatus', component: ViewBookingStatusComponent }
      { path: 'viewmanagertravelrequest', component: ViewManagerTravelRequestComponent },
      { path: 'managerstraveldetails/:travelRequestId', component: ViewManagerBookingStatusComponent }
    ]
  },
  {
    path: 'directorhome', component: DirectorHomeComponent,
    children: [
      { path: 'viewemployeetravelrequest', component: ViewEmployeeTravelRequestComponent }
    ]
  },
  {
    path: 'travelagenthome', component: TravelagentHomeComponent,
    children: [
      { path: 'bookingdetails', component: BookingDetailsComponent },
      { path: 'employeetravelrequests', component: AgentTravelRequestListComponent },
      { path: 'validaterequest/:travelRequestId', component: ValidateRequestComponent },
      { path: 'makenewbookings/:travelRequestId', component: MakeNewBookingsComponent }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
