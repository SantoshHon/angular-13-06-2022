import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { travelAgentDetails } from '../pojo/TravelAgentDetails';

@Injectable({
  providedIn: 'root'
})
export class TravalAgentDetailsService{

  private baseURL: string = "http://localhost:8080/agentdetails/agentdetail";
  constructor(private http: HttpClient) { }

  getAllTravelAgentDetails(): Observable<travelAgentDetails[]> {
    return this.http.get<travelAgentDetails[]>(this.baseURL);
  }

  getTravelAgentDetailsByagentId(agentId: number): Observable<travelAgentDetails> {
    console.log('in get single employee'+agentId);
    return this.http.get<travelAgentDetails>(this.baseURL + '/' + agentId);
  }
}
