import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/EmployeeDetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {
  private baseURL: string = "http://localhost:8080/employeetraval/employeedetails";
  private baseURLForByLoginId: string = "http://localhost:8080/employeetraval/employeedetailsbyloginid";
  constructor(private http: HttpClient) { }

  getAllEmployeeDetails(): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(this.baseURL);
  }

  getEmployeeDetailsByemployeeDetailsId(employeeDetailsId: number): Observable<EmployeeDetails> {
    console.log('in get single employee'+employeeDetailsId);
    return this.http.get<EmployeeDetails>(this.baseURL + '/' + employeeDetailsId);
  }
  getEmployeeByLoginId(loginId:number):Observable<EmployeeDetails>{
    return this.http.get<EmployeeDetails>(this.baseURLForByLoginId + '/' + loginId);
  }
}

