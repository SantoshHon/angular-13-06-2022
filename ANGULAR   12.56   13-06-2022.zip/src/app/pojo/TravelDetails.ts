export class TravelDetails {
    travelDetailsId: number = 0;
    hotelName: string = '';
    hotelAddress: string = '';
    hotelBookingStatus: string = '';
    travelDepartureDate: Date = new Date();
    travelReturnDate: Date = new Date();
    ticketBookingStatus: string = '';
    accommodation: number = 0;
}