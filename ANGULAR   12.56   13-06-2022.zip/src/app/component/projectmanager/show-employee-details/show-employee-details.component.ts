import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';
import { ProjectmanagerHomeComponent } from '../projectmanager-home/projectmanager-home.component';

@Component({
  selector: 'app-show-employee-details',
  templateUrl: './show-employee-details.component.html',
  styleUrls: ['./show-employee-details.component.css']
})
export class ShowEmployeeDetailsComponent implements OnInit {
  travelRequestId: number = 0;
  travellingRequestDetails:TravellingRequestDetails=new TravellingRequestDetails();
  employeeDetails:EmployeeDetails=new EmployeeDetails();
  managerAction:string='';
  // submitted:boolean=false;

  constructor(private router: Router, private projectmanagerHomeComponent: ProjectmanagerHomeComponent, private route: ActivatedRoute,private travelingRequestDetailsService:TravelingRequestDetailsService) { }

  ngOnInit(): void {
    this.travelRequestId = this.route.snapshot.params['travelRequestId'];
    console.log(this.travelRequestId);
    this.loadEmoloyeeDetails();
  }
  loadEmoloyeeDetails(){
    // this.submitted=false;
    this.travelingRequestDetailsService.getTravellingRequestDetailsBytravelRequestId(this.travelRequestId).subscribe(
      data=>{
        this.travellingRequestDetails=data;
        this.employeeDetails=this.travellingRequestDetails.employeeDetails;
        console.log(this.employeeDetails);
        
      });
  }
  goTotravelDetails() {
    // this.submitted=true;
    // this.projectmanagerHomeComponent.submitted = false;
  }
  approveButton() {
    this.managerAction = 'APPROVED';
    this.travellingRequestDetails.projectManagerStatus = this.managerAction;
    this.updateStatus();
    // this.loadEmoloyeeDetails();
  }

  rejectButton() {
    this.managerAction = 'REJECTED';
    this.travellingRequestDetails.projectManagerStatus = this.managerAction;
    this.updateStatus();
    // this.loadEmoloyeeDetails();
  }

  updateStatus() {
    this.travelingRequestDetailsService.updateManagerStatusBytravelRequestId(this.travellingRequestDetails).subscribe(
      data => {
        console.log(data);
      }
    );
  }
}
