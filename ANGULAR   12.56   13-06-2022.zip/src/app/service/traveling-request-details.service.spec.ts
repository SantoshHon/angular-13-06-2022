import { TestBed } from '@angular/core/testing';

import { TravelingRequestDetailsService } from './traveling-request-details.service';

describe('TravlingRequestDetailsService', () => {
  let service: TravelingRequestDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelingRequestDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
