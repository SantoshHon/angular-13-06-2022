export class LoginDetails {
    loginId: number = 0;
    password: string = '';
    role: string = '';

}