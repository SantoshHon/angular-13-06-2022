import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { LoginDetails } from 'src/app/pojo/logindetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-make-travel-request',
  templateUrl: './make-travel-request.component.html',
  styleUrls: ['./make-travel-request.component.css']
})
export class MakeTravelRequestComponent implements OnInit {
  travelRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();
  employeeDetails:EmployeeDetails=new EmployeeDetails();
  loginDetails:LoginDetails=new LoginDetails();
  submitted: boolean = false;
  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private router: Router) { }

  onSubmitRequest() {
    console.log(this.travelRequestDetails);
      this.travelingRequestDetailsService.upadateMakeTravelRequest(this.travelRequestDetails).subscribe(
        data => {
          this.travelRequestDetails=data;
          this.submitted=true;
           console.log(data);
         
        }
      );
  }
  goToHome(){
    this.router.navigate(['/employeehome']);
  }
  ngOnInit(): void {
    this.employeeDetails=JSON.parse(sessionStorage.getItem('employee')||'{}');
    this.travelRequestDetails.employeeDetails = this.employeeDetails;
  }

}
