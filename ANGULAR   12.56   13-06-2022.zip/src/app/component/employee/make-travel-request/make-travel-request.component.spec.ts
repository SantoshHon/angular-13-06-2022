import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MakeTravelRequestComponent } from './make-travel-request.component';

describe('MakeTravelRequestComponent', () => {
  let component: MakeTravelRequestComponent;
  let fixture: ComponentFixture<MakeTravelRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MakeTravelRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MakeTravelRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
