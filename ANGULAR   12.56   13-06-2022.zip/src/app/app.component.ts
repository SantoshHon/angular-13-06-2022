import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  hide : boolean=true;
  title = 'employee-travel-management';
  change(){
    this.hide=false;
  }
}
