import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TravelDetails } from '../pojo/TravelDetails';

@Injectable({
  providedIn: 'root'
})
export class TraveldetailsServiceService {
  private baseURL: string = "http://localhost:8080/traveldetails/traveldetail";
  constructor(private http: HttpClient) { }

  getAllTravelDetails(): Observable<TravelDetails[]> {
    return this.http.get<TravelDetails[]>(this.baseURL);
  }

  getTravelDetailsByTravelDetailsId(travelDetailsId: number): Observable<TravelDetails> {
    console.log('in get single employee'+travelDetailsId);
    return this.http.get<TravelDetails>(this.baseURL + '/' + travelDetailsId);
  }
}
