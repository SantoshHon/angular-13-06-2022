import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginDetails } from '../pojo/logindetails';

@Injectable({
  providedIn: 'root'
})
export class LoginDetailsService {
  private baseURL: string = "http://localhost:8080/logins/login";
  constructor(private http: HttpClient,route:ActivatedRoute) { }

  getAllLoginDetails(): Observable<LoginDetails[]> {
    return this.http.get<LoginDetails[]>(this.baseURL);
  }

  getLoginDetailsByloginId(loginId: number): Observable<LoginDetails> {
    return this.http.get<LoginDetails>(this.baseURL + '/' + loginId);
  }


  userLogin(loginDetails:LoginDetails):Observable<LoginDetails>{
    console.log("i am in user login")
    return this.http.post<LoginDetails>(this.baseURL,loginDetails);
  }
}
