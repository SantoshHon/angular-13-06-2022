import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEmployeeTravelRequestComponent } from './view-employee-travel-request.component';

describe('ViewEmployeeTravelRequestComponent', () => {
  let component: ViewEmployeeTravelRequestComponent;
  let fixture: ComponentFixture<ViewEmployeeTravelRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEmployeeTravelRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewEmployeeTravelRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
