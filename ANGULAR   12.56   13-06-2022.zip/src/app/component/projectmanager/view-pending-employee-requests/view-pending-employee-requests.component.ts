import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-view-pending-employee-requests',
  templateUrl: './view-pending-employee-requests.component.html',
  styleUrls: ['./view-pending-employee-requests.component.css']
})
export class ViewPendingEmployeeRequestsComponent implements OnInit {

  travelRequests: TravellingRequestDetails[] = [];
  approvedTravelRequests: TravellingRequestDetails[] = [];
  rejectedTravelRequests: TravellingRequestDetails[] = [];
  pendingTravelRequests: TravellingRequestDetails[] = [];

  employeeDetails: EmployeeDetails = new EmployeeDetails();
  travellingRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();
  managerId: number = 0;
  agentAction: string = '';
  travelRequestId: number = 0;

  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.employeeDetails = JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.managerId = this.employeeDetails.employeeDetailsId;
    this.getRequests();
    this.getAllApprovedRequests();
    this.getAllPendingRequests();
    this.getAllRejectedRequests();
  }
  getAllApprovedRequests() {
    this.travelingRequestDetailsService.getAllTravellingAcceptRequestByManagerId(this.managerId).subscribe(data => {
      this.approvedTravelRequests = data;
    })
  }
  getAllRejectedRequests() {
    this.travelingRequestDetailsService.getAllTravellingRejectedRequestByManagerId(this.managerId).subscribe(data => {
      this.rejectedTravelRequests = data;
    })
  }
  getAllPendingRequests() {
    this.travelingRequestDetailsService.getAllTravellingPendingRequestByManagerId(this.managerId).subscribe(data => {
      this.pendingTravelRequests = data;
    })
  }
  getRequests() {
    this.travelingRequestDetailsService.getTravelRequestsByManagerId(this.managerId).subscribe(
      data => {
        this.travelRequests = data;
      }
    );
  }

  getEmployeeDetails(travelRequestId: number) {
    this.router.navigate(['/projectmanagerhome/showemployeedetails', travelRequestId]);
  }


}
